<?php
$conn=mysqli_connect('127.0.0.1:3308','myadmin','Angular13')
or die(mysqli_error());
//$conn=mysqli_connect('locahost','root','')
//or die(mysqli_error());
mysqli_select_db($conn,'phpcrud') or die(mysqli_error());
?>