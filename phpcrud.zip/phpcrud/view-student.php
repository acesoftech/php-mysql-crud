<?php
include('db_connect.php'); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>PHP CRUD</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
<main class="container">
	<?php include('header.php');?>

<div>
 <table class="table table-striped">
     <thead>
         <th>First Name</th>
          <th>Last Name</th>
           <th>Email</th>
           <th>Password</th>
            <th>Gender</th>
            <th>Hobbies</th>
            <th>Country</th>
            <th>Action</th>
     </thead>
     <tbody>
  <?php 
  $sel ="select * from students";
  $qry=mysqli_query($conn,$sel);
  while($rows=mysqli_fetch_array($qry)){
  ?>
         <tr>
             <td><?php echo $rows['first_name']; ?></td>
             <td><?php echo $rows['last_name']; ?></td>
             <td><?php echo $rows['email']; ?></td>
             <td><?php echo $rows['password']; ?></td>
             <td><?php echo $rows['gender']; ?></td>
             <td><?php echo $rows['hobbies']; ?></td>
             <td><?php echo $rows['country']; ?></td>
             <td> <a href="edit.php?id=<?php echo $rows['id']; ?>" class="btn btn-success">EDIT</a> 
              <a href="delete.php?id=<?php echo $rows['id']; ?>" class="btn btn-danger">DELETE</a></td>
         </tr>
        <?php 
          }
          ?>
     </tbody>
 </table>
</div>
</main>
</body>
</html>