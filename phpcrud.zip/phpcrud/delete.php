<?php
 include('db_connect.php');
 if($_GET){

 	$del="delete from students where id=".$_GET['id'];
 	mysqli_query($conn,$del);
 	header('location:view-student.php');
 }
?>