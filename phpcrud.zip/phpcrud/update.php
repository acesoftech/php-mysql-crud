<?php
include('db_connect.php');

if($_POST){

    $hobbies = $_POST['hobbies'];
    $hbs='';
    for ($i=0; $i<count($hobbies);$i++) {
       
       $hbs .= $hobbies[$i].',';
    }

	$upd="update students set
    first_name='".$_POST['first_name']."',
    last_name='".$_POST['last_name']."',
    email='".$_POST['email']."',
    password='".$_POST['password']."',
    gender='".$_POST['gender']."',
    hobbies='".$hbs."',
    country='".$_POST['country']."'";

    $qry=mysqli_query($conn,$upd);
    header('Location:view-student.php');
}
?>